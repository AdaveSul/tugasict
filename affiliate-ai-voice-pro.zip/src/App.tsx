import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  Sparkles, 
  Download, 
  Play, 
  Pause, 
  Settings2, 
  Volume2, 
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  Type,
  FileText
} from 'lucide-react';
import { generateScript, generateVoice } from './services/geminiService';
import { cn } from './lib/utils';
import ReactMarkdown from 'react-markdown';

const VOICES = [
  { id: 'Zephyr', name: 'Bambang (Tenang & Dalam)', gender: 'Pria' },
  { id: 'Puck', name: 'Yanto (Energik)', gender: 'Pria' },
  { id: 'Charon', name: 'Budi (Formal)', gender: 'Pria' },
  { id: 'Kore', name: 'Siti (Lembut & Ramah)', gender: 'Wanita' },
  { id: 'Fenrir', name: 'Gatot (Tegas)', gender: 'Pria' },
];

export default function App() {
  const [productName, setProductName] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [script, setScript] = useState('');
  const [selectedVoice, setSelectedVoice] = useState(VOICES[0].id);
  const [pitch, setPitch] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleGenerateScript = async () => {
    if (!productName) {
      setError('Nama produk harus diisi!');
      return;
    }
    setError(null);
    setIsGeneratingScript(true);
    try {
      const generated = await generateScript(productName, productDesc);
      setScript(generated);
    } catch (err) {
      setError('Gagal membuat skrip. Coba lagi.');
      console.error(err);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleGenerateVoice = async () => {
    if (!script) {
      setError('Skrip kosong! Buat skrip terlebih dahulu.');
      return;
    }
    setError(null);
    setIsGeneratingVoice(true);
    try {
      const base64 = await generateVoice(script, selectedVoice);
      const blob = await fetch(`data:audio/wav;base64,${base64}`).then(res => res.blob());
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.playbackRate = speed;
      }
    } catch (err) {
      setError('Gagal membuat suara. Coba lagi.');
      console.error(err);
    } finally {
      setIsGeneratingVoice(false);
    }
  };

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const downloadAudio = () => {
    if (audioUrl) {
      const a = document.createElement('a');
      a.href = audioUrl;
      a.download = `${productName.replace(/\s+/g, '_')}_voice.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  }, [speed]);

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-white font-sans selection:bg-purple-500/30">
      {/* Background Glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-purple-600/10 blur-[120px] rounded-full" />
        <div className="absolute top-[20%] -right-[10%] w-[30%] h-[30%] bg-blue-600/10 blur-[120px] rounded-full" />
      </div>

      <div className="relative max-w-5xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="flex items-center justify-between mb-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Mic className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              VoiceAffiliate AI
            </h1>
          </div>
          <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/10 text-sm text-gray-400">
            <CheckCircle2 className="w-4 h-4 text-green-500" />
            <span>Gemini AI Connected</span>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Inputs */}
          <div className="lg:col-span-7 space-y-8">
            <section className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h2 className="text-lg font-semibold">Product Details</h2>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Nama Produk</label>
                  <input 
                    type="text"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    placeholder="Contoh: Headphone Wireless Noise Cancelling"
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Deskripsi Produk (Opsional)</label>
                  <textarea 
                    value={productDesc}
                    onChange={(e) => setProductDesc(e.target.value)}
                    placeholder="Jelaskan fitur utama, manfaat, atau target audiens..."
                    rows={4}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all resize-none"
                  />
                </div>
                <button
                  onClick={handleGenerateScript}
                  disabled={isGeneratingScript || !productName}
                  className={cn(
                    "w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all",
                    isGeneratingScript 
                      ? "bg-gray-800 text-gray-500 cursor-not-allowed" 
                      : "bg-white text-black hover:bg-gray-200 active:scale-[0.98]"
                  )}
                >
                  {isGeneratingScript ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <Type className="w-5 h-5" />
                  )}
                  {isGeneratingScript ? 'Menghasilkan Skrip...' : 'Buat Skrip'}
                </button>
              </div>
            </section>

            <AnimatePresence>
              {script && (
                <motion.section 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-blue-400" />
                      <h2 className="text-lg font-semibold">Generated Script</h2>
                    </div>
                    <button 
                      onClick={() => setScript('')}
                      className="text-xs text-gray-500 hover:text-white transition-colors"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="bg-black/40 border border-white/5 rounded-2xl p-6 text-gray-300 leading-relaxed prose prose-invert max-w-none">
                    <ReactMarkdown>{script}</ReactMarkdown>
                  </div>
                </motion.section>
              )}
            </AnimatePresence>
          </div>

          {/* Right Column: Voice Settings & Player */}
          <div className="lg:col-span-5 space-y-8">
            <section className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm sticky top-8">
              <div className="flex items-center gap-2 mb-8">
                <Settings2 className="w-5 h-5 text-blue-400" />
                <h2 className="text-lg font-semibold">Voice Settings</h2>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-4 text-center">Pilih Karakter Suara</label>
                  <div className="grid grid-cols-1 gap-3">
                    {VOICES.map((voice) => (
                      <button
                        key={voice.id}
                        onClick={() => setSelectedVoice(voice.id)}
                        className={cn(
                          "flex items-center justify-between px-4 py-3 rounded-xl border transition-all text-left",
                          selectedVoice === voice.id
                            ? "bg-purple-600/20 border-purple-500 text-white"
                            : "bg-black/40 border-white/5 text-gray-400 hover:border-white/20"
                        )}
                      >
                        <div className="flex flex-col">
                          <span className="font-medium">{voice.name}</span>
                          <span className="text-[10px] uppercase tracking-wider opacity-50">{voice.gender}</span>
                        </div>
                        {selectedVoice === voice.id && <CheckCircle2 className="w-4 h-4 text-purple-400" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <label className="text-sm font-medium text-gray-400">Kecepatan (Speed)</label>
                      <span className="text-xs text-purple-400 font-mono">{speed}x</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.5" 
                      max="2" 
                      step="0.1" 
                      value={speed}
                      onChange={(e) => setSpeed(parseFloat(e.target.value))}
                      className="w-full accent-purple-500 h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  {/* Pitch is simulated via playbackRate in some browsers or just a placeholder for now as Gemini TTS is prebuilt */}
                  <div>
                    <div className="flex justify-between mb-2">
                      <label className="text-sm font-medium text-gray-400">Intensitas Nada (Tone)</label>
                      <span className="text-xs text-blue-400 font-mono">{pitch}x</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.5" 
                      max="1.5" 
                      step="0.1" 
                      value={pitch}
                      onChange={(e) => setPitch(parseFloat(e.target.value))}
                      className="w-full accent-blue-500 h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>

                <button
                  onClick={handleGenerateVoice}
                  disabled={isGeneratingVoice || !script}
                  className={cn(
                    "w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all shadow-xl shadow-purple-500/10",
                    isGeneratingVoice || !script
                      ? "bg-gray-800 text-gray-500 cursor-not-allowed" 
                      : "bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:opacity-90 active:scale-[0.98]"
                  )}
                >
                  {isGeneratingVoice ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                  {isGeneratingVoice ? 'Mensintesis Suara...' : 'Hasilkan Voice-Over'}
                </button>

                {/* Audio Player Section */}
                <AnimatePresence>
                  {audioUrl && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-black/60 border border-white/10 rounded-2xl p-6 space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-gray-500 uppercase tracking-widest">Pratinjau Hasil</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={togglePlay}
                            className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                          >
                            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                          </button>
                          <button 
                            onClick={downloadAudio}
                            className="w-10 h-10 bg-white/10 text-white rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                            title="Download WAV"
                          >
                            <Download className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                      <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-gradient-to-r from-purple-500 to-blue-500"
                          animate={{ width: isPlaying ? '100%' : '0%' }}
                          transition={{ duration: isPlaying ? 10 : 0, ease: "linear" }}
                        />
                      </div>
                      <audio 
                        ref={audioRef} 
                        onEnded={() => setIsPlaying(false)}
                        onPlay={() => setIsPlaying(true)}
                        onPause={() => setIsPlaying(false)}
                        className="hidden"
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </section>
          </div>
        </div>

        {/* Error Toast */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-red-500/90 backdrop-blur-md text-white px-6 py-3 rounded-full flex items-center gap-2 shadow-2xl border border-red-400/20"
            >
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
