import { GoogleGenAI, Modality } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const genAI = new GoogleGenAI({ apiKey: apiKey || "" });

export const generateScript = async (productName: string, productDescription: string) => {
  const model = genAI.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Buatlah skrip iklan pendek (affiliate marketing) yang sangat menarik dan persuasif dalam Bahasa Indonesia untuk produk berikut:
    Nama Produk: ${productName}
    Deskripsi Produk: ${productDescription}
    
    Ketentuan Skrip:
    1. Gaya bahasa santai, kekinian (gaul), dan cocok untuk audiens TikTok/Reels/Shorts di Indonesia.
    2. Gunakan hook yang kuat di awal.
    3. Sertakan Call to Action (CTA) yang jelas.
    4. Berikan hanya teks skripnya saja tanpa tambahan penjelasan lain atau tanda kutip di awal/akhir.`,
  });

  const response = await model;
  return response.text || "";
};

export const generateVoice = async (text: string, voiceName: string) => {
  const response = await genAI.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("Gagal menghasilkan audio.");
  }

  return base64Audio;
};
